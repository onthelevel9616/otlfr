# About Us Page - Final

A Pen created on CodePen.

Original URL: [https://codepen.io/Alyssa-Sanchez-the-animator/pen/YPXxBZr](https://codepen.io/Alyssa-Sanchez-the-animator/pen/YPXxBZr).

